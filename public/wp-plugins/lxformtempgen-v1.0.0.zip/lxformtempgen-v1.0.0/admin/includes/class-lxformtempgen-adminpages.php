<?php

class LXFormTempGen_AdminPages {
    private $loader;

	public function __construct( $loader ) {
		$this->loader = $loader;
	}

	public function init() {
		$this->loader->add_action( 'admin_menu', $this, 'register_admin_menu' );
		$this->loader->add_filter( 'admin_body_class', $this, 'body_class' );
	}
    
    public function register_admin_menu() {
        add_menu_page(
            __( 'Templates -' . LXFORMTEMPGEN_NAME, 'lxformtempgen' ),
            'LXF Templates',
            'manage_options',
            'lxformtempgen',
            [$this, 'formtemplate_callback'],
            // 'dashicons-email',
            plugin_dir_url( dirname(__FILE__) ) . 'images/icon.png',
            26
        );

        add_submenu_page(
            'lxformtempgen',
            'Templates -' . LXFORMTEMPGEN_NAME,
            'All Templates',
            'manage_options',
            'lxformtempgen',
            [$this, 'formtemplate_callback'],
        );

        add_submenu_page(
            'lxformtempgen',
            'Create Template - '. LXFORMTEMPGEN_NAME,
            'Add New',
            'manage_options',
            'lxformtempgen-create',
            [$this, 'formtemplate_callback'],
        );

        add_submenu_page(
            null,
            'Edit Template - '. LXFORMTEMPGEN_NAME,
            'Edit Template',
            'manage_options',
            'lxformtempgen&action=lxformtempgen-edit',
            [$this, 'formtemplate_callback'],
        );

        add_submenu_page(
            'lxformtempgen',
            'Categories - '. LXFORMTEMPGEN_NAME,
            'Categories',
            'manage_options',
            'lxformtempgen-category',
            [$this, 'formtemplate_callback'],
        );

        add_submenu_page(
            null,
            'Create Category - '. LXFORMTEMPGEN_NAME,
            'Create Category',
            'manage_options',
            'lxformtempgen-category&action=lxformtempgen-category-create',
            [$this, 'formtemplate_callback'],
        );

        add_submenu_page(
            null,
            'Edit Category - '. LXFORMTEMPGEN_NAME,
            'Edit Category',
            'manage_options',
            'lxformtempgen-category&action=lxformtempgen-category-edit',
            [$this, 'formtemplate_callback'],
        );

        add_submenu_page(
            'lxformtempgen',
            'Settings - '. LXFORMTEMPGEN_NAME,
            'Settings',
            'manage_options',
            'lxformtempgen-settings',
            [$this, 'formtemplate_callback'],
        );
    }

    public function formtemplate_callback() {
        return $this->loader->admin_view('lxformtempgen-app');
    }

    public function body_class( $classes ) {
        $screen = get_current_screen();

        if ( get_plugin_page_hook( 'lxformtempgen', '' ) === $screen->id ) {
            $classes .= ' lxftg-body lxftg-listing';
        } elseif ( get_plugin_page_hook( 'lxformtempgen-create', 'lxformtempgen' ) === $screen->id ) {
            $classes .= ' lxftg-body lxftg-create';
        } elseif ( get_plugin_page_hook( 'lxformtempgen-settings', 'lxformtempgen' ) === $screen->id ) {
            $classes .= ' lxftg-body lxftg-settings';
        } elseif ( get_plugin_page_hook( 'lxformtempgen-category', 'lxformtempgen' ) === $screen->id ) {
            $classes .= ' lxftg-body lxftg-category';
        }
    
        return $classes;
    }
}