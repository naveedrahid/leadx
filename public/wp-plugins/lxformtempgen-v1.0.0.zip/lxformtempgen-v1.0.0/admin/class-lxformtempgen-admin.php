<?php

class LXFormTempGen_Admin {
	private $loader;

	public function __construct( $loader ) {
		$this->loader = $loader;
	}

	public function init() {
		$this->loader->add_action( 'admin_enqueue_scripts', $this, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $this, 'enqueue_scripts' );
	}

	public function enqueue_styles( $hook ) {
		if(
			$hook === 'toplevel_page_lxformtempgen' || 
            $hook === 'lxf-templates_page_lxformtempgen-create' || 
            $hook === 'lxf-templates_page_lxformtempgen-settings' || 
            $hook === 'lxf-templates_page_lxformtempgen-category'
        ) {
			wp_enqueue_style(LXFORMTEMPGEN_ID.'-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css', array(), null, 'all' );
            wp_enqueue_style(LXFORMTEMPGEN_ID.'-lineawesome', 'https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css', array(), null, 'all' );
            wp_enqueue_style(LXFORMTEMPGEN_ID, plugin_dir_url( __FILE__ ) . 'css/'.LXFORMTEMPGEN_ID.'-admin.css', array(), null, 'all' );
		}
	}

	public function enqueue_scripts( $hook ) {
		wp_enqueue_script(LXFORMTEMPGEN_ID.'-ace', 'https://cdn.jsdelivr.net/npm/ace-builds@1.31.1/src-min-noconflict/ace.min.js', array(), null, true);
		wp_enqueue_script(LXFORMTEMPGEN_ID, plugin_dir_url( __FILE__ ) . 'js/'.LXFORMTEMPGEN_ID.'-admin.js', array( 'jquery' ), null, true );
		wp_localize_script(LXFORMTEMPGEN_ID, 'lxformtempgenData', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'lxformtempgen-nonce' ),
			'plugin_name' => LXFORMTEMPGEN_NAME,
			'plugin_dir' => plugin_dir_url( __FILE__ ),
			'plugin_version' => LXFORMTEMPGEN_VERSION,
			'admin_url' => admin_url(),
			'admin_email' => get_bloginfo('admin_email'),
			'site_title' => get_bloginfo('name'),
			'site_url' => get_bloginfo('url'),
			'api_url' => $this->loader->api_url(),
			'isReCaptchaIntegrated' => $this->loader->has_reCaptcha_keys()
		));
	}
}
