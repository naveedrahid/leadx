<main class="lxftg-wrap">
    <div id="lxftgapp"></div>
</main>