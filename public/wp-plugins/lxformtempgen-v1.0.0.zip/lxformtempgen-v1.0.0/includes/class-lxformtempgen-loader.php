<?php

class LXFormTempGen_Loader {
	protected $actions;
	protected $filters;
	protected $api_url = 'https://leadxforms.com/api/v1';
	protected $website_link = 'https://leadxforms.com/';
	
	public function __construct() {
		$this->actions = array();
		$this->filters = array();
	}

	public function add_action( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
		$this->actions = $this->add( $this->actions, $hook, $component, $callback, $priority, $accepted_args );
	}

	public function add_filter( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
		$this->filters = $this->add( $this->filters, $hook, $component, $callback, $priority, $accepted_args );
	}

	private function add( $hooks, $hook, $component, $callback, $priority, $accepted_args ) {
		$hooks[] = array(
			'hook'          => $hook,
			'component'     => $component,
			'callback'      => $callback,
			'priority'      => $priority,
			'accepted_args' => $accepted_args
		);
		return $hooks;
	}

	public function run() {
		foreach ( $this->filters as $hook ) {
			add_filter( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
		}

		foreach ( $this->actions as $hook ) {
			add_action( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
		}
	}

	public function api_url() {
		return $this->api_url;
	}

	public function website_link() {
		return $this->website_link;
	}

	public function has_reCaptcha_keys() {
		$lxformtempgen_reCaptcha_keys = get_option('lxformtempgen_reCaptcha_keys');
		if(isset($lxformtempgen_reCaptcha_keys) && !empty($lxformtempgen_reCaptcha_keys)) {
			return 1;
		}

		return 0;
	}

	public function is_internet_on() {
        $response = @file_get_contents('https://www.google.com/');
        return ($response !== false);
    }

	public function verify_nonce($nonce) {
		return wp_verify_nonce( $_POST['nonce'], $nonce ) ? true : false;
    }

	public function admin_view($file_path, $data = []) {
		extract($data);
		include_once(plugin_dir_path(dirname(__FILE__)) . 'admin/partials/'. $file_path .'.php');
	}

	public function getdomain() {
		// $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
		$domain = $_SERVER['HTTP_HOST'];
		$url = $domain;
		return $url;
	}
}
