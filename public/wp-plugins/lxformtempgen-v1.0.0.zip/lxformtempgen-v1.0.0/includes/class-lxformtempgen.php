<?php

class LXFormTempGen {
	protected $loader;
	protected $dependencies = [
		'includes/class-lxformtempgen-loader.php',
		'includes/class-lxformtempgen-i18n.php',
		'includes/class-lxformtempgen-maildata-filter.php',
		'includes/class-lxformtempgen-visitordetails.php',
		'includes/class-lxformtempgen-smtp-connect.php',

		'includes/shorttags/class-lxformtempgen-shorttag-tag.php',
		'includes/shorttags/class-lxformtempgen-shorttag-checkbox-list.php',
		'includes/shorttags/class-lxformtempgen-shorttag-checkbox.php',
		'includes/shorttags/class-lxformtempgen-shorttag-date.php',
		'includes/shorttags/class-lxformtempgen-shorttag-email.php',
		'includes/shorttags/class-lxformtempgen-shorttag-file.php',
		'includes/shorttags/class-lxformtempgen-shorttag-hidden.php',
		'includes/shorttags/class-lxformtempgen-shorttag-number.php',
		'includes/shorttags/class-lxformtempgen-shorttag-radio.php',
		'includes/shorttags/class-lxformtempgen-shorttag-range.php',
		'includes/shorttags/class-lxformtempgen-shorttag-recaptcha.php',
		'includes/shorttags/class-lxformtempgen-shorttag-select.php',
		'includes/shorttags/class-lxformtempgen-shorttag-submit.php',
		'includes/shorttags/class-lxformtempgen-shorttag-tel.php',
		'includes/shorttags/class-lxformtempgen-shorttag-text.php',
		'includes/shorttags/class-lxformtempgen-shorttag-textarea.php',
		'includes/shorttags/class-lxformtempgen-shorttag-url.php',

		'includes/class-lxformtempgen-formtemplate.php',

		'includes/wp_ajax/class-lxformtempgen-wpajax-template-preview.php',
		'includes/wp_ajax/class-lxformtempgen-wpajax-recaptcha-get-keys.php',
		'includes/wp_ajax/class-lxformtempgen-wpajax-recaptcha-integration.php',
		'includes/wp_ajax/class-lxformtempgen-wpajax-smtp-get-details.php',
		'includes/wp_ajax/class-lxformtempgen-wpajax-smtp-save-details.php',

		'includes/shortcodes/class-lxformtempgen-shortcode-form.php',

		'includes/traits/class-lxformtempgen-trait-validator.php',

		'admin/class-lxformtempgen-admin.php',
		'admin/includes/class-lxformtempgen-adminpages.php',

		'public/class-lxformtempgen-public.php',
		'public/includes/wp_ajax/class-lxformtempgen-wpajax-form-submit.php',
	];

	protected $services = [
		'LXFormTempGen_i18n',
		'LXFormTempGen_SmtpConnect',

		'LXFormTempGen_WpAjax_TemplatePreview',
		'LXFormTempGen_WpAjax_RecaptchaGetKeys',
		'LXFormTempGen_WpAjax_RecaptchaIntegration',
		'LXFormTempGen_WpAjax_SmtpGetDetails',
		'LXFormTempGen_WpAjax_SmtpSaveDetails',

		'LXFormTempGen_Shortcode_Form',

		'LXFormTempGen_Admin',
		'LXFormTempGen_AdminPages',
		
		'LXFormTempGen_Public',
		'LXFormTempGen_WpAjax_TemplateSubmit',
	];

	public function __construct() {
		$this->load_dependencies();
		$this->loader = new LXFormTempGen_Loader();

		$this->load_services();
	}

	private function load_dependencies() {
		if(count($this->dependencies)) {
            foreach($this->dependencies as $path) {
                require_once(plugin_dir_path( dirname( __FILE__ ) ) . $path);
            }
        }
	}

	private function load_services() {
		$services = $this->services;
        if(count($services)) {
            foreach($services as $class) {
                $service = new $class($this->loader);
                if(method_exists($service, 'init')) {
                    $service->init();
                }
            }
        }
	}

	public function run() {
		$this->loader->run();
	}

	public function get_loader() {
		return $this->loader;
	}
}
