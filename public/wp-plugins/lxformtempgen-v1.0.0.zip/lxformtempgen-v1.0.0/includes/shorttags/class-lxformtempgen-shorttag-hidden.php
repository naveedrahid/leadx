<?php

class LXFormTempGen_ShortCode_Hidden extends LXFormTempGen_ShortCode_Tag {

    protected $attributes = [
        'name',
        'id',
        'class',
        'value'
    ];

    protected $rules = [];

    public function output() {
        $attr = $this->attributes();

        $output = '<span class="lxformtempgen-field-warp lxformtempgen-hidden-wrap" data-name="'. $attr['name'] .'">';
            $output .= '<input type="hidden"';
            $output .= ($attr['name']) ? ' name="'. $attr['name'] .'"' : '';
            $output .= ($attr['id']) ? ' id="'. $attr['id'] .'"' : '';
            $output .= ' class="lxformtempgen-field lxformtempgen-hidden '. $attr['class'] .'"';
            $output .= ($attr['value']) ? ' value="'. $attr['value'] .'"' : '';
            $output .= '>';
        $output .= '</span>';

        return $output;
    }
}