<?php

class LXFormTempGen_ShortCode_Submit extends LXFormTempGen_ShortCode_Tag {

    protected $attributes = [
        'text',
        'id',
        'class',
    ];

    protected $rules = [];

    public function output() {
        $attr = $this->attributes();

        $output = '<span class="lxformtempgen-submit">';
            $output .= '<button type="submit"';
            $output .= ($attr['id']) ? ' id="'. $attr['id'] .'"' : '';
            $output .= ' class="lxformtempgen-submit-btn '. $attr['class'] .'"';
            $output .= '>';
            $output .= ($attr['text']) ? $attr['text'] : '';
            $output .= '</button>';
        $output .= '</span>';

        return $output;
    }
}