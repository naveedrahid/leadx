<?php

class LXFormTempGen_Shortcode_Form {

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }
	
    public function init() {
        add_shortcode(LXFORMTEMPGEN_ID, [$this, 'shortcode']);
    }

    public function shortcode($atts) {
        global $wp;
        $atts = shortcode_atts(['key' => null], $atts);

        if(!empty($atts)) {
            $response = wp_remote_get( $this->loader->api_url() . '/template?form_key=' . $atts['key'], [
                'sslverify' => false
            ]);

            if ( is_wp_error( $response ) ) {
                return '<div class="lxftg-form-error">Error: Could not connect to the API</div>';
            }
            
            $body = wp_remote_retrieve_body( $response );
            $result = json_decode( $body );
            
            if ( empty( $result ) || empty( $result->data ) || !is_array( $result->data ) || !count( $result->data ) ) {
                return '<div class="lxftg-form-error">Error: Form Not Found</div>';
            } elseif ( !isset( $result->data[0]->form_key ) || $result->data[0]->form_key !== $atts['key'] ) {
                return '<div class="lxftg-form-error">Error: Form Not Found</div>';
            }

            $form_data = $result->data[0];
            $template = (new LXFormTempGen_FormTemplate)->set($form_data->template);
            $rules = $template->rules();
            $names = $template->names();
            $fields = $template->fields();
            $form_template = $template->output();

            wp_enqueue_style( LXFORMTEMPGEN_ID, plugin_dir_url( __FILE__ ) . '../../public/css/lxformtempgen-public.css', [], null, 'all' );
            if(isset($fields['recaptcha'])) {
                wp_enqueue_script( LXFORMTEMPGEN_ID.'-recaptcha', 'https://www.google.com/recaptcha/api.js', [], null, true );    
                wp_script_add_data(LXFORMTEMPGEN_ID.'-recaptcha', 'async', true);
                wp_script_add_data(LXFORMTEMPGEN_ID.'-recaptcha', 'defer', true);
            }
            wp_enqueue_script( LXFORMTEMPGEN_ID, plugin_dir_url( __FILE__ ) . '../../public/js/lxformtempgen-public.js', [], null, true );

            wp_localize_script( LXFORMTEMPGEN_ID, 'lxformtempgenData', array(
                'ajax_url' => admin_url( 'admin-ajax.php' )
            ));

            if($form_data->custom_css) {
                wp_add_inline_style( LXFORMTEMPGEN_ID, $form_data->custom_css );
            }

            ob_start(); ?>
            <div class="lxformtempgen-form-wrap">
                <form action="<?php echo home_url( $wp->request ); ?>" method="post" class="lxformtempgen-form" aria-label="<?php echo $form_data->form_name; ?>" novalidate>
                    <?php wp_nonce_field( 'lxformtempgen-nonce', 'nonce' ); ?>
                    <input type="hidden" name="lxftgstarttime" value="<?= time(); ?>">
                    <label for="request-checker" aria-hidden="true" class="request-checker"><input type="radio" name="request-checker" id="request-checker" value="1"></label>
                    <div class="lxformtempgen-form-innerwrap">
                        <input type="hidden" name="_key" value="<?php echo $form_data->form_key; ?>">
                        <?php echo $form_template; ?>
                    </div>
                </form>
            </div>
            <?php $output = ob_get_contents();
            ob_end_clean();

            return $output;
        }
    }
}