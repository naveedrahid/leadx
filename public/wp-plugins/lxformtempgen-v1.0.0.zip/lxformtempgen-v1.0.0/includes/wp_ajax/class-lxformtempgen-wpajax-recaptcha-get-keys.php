<?php

class LXFormTempGen_WpAjax_RecaptchaGetKeys {

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }

    public function init() {
        $this->loader->add_action('wp_ajax_lxftg_recaptcha_get_keys', $this, 'request');
        $this->loader->add_action('wp_ajax_nopriv_lxftg_recaptcha_get_keys', $this, 'request');
    }

    public function request() {
        if ( !$this->loader->verify_nonce( 'lxformtempgen-nonce' ) ) {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Permission Denied!', 'lxformtempgen')
            ]);
            wp_die();
        }

        $lxformtempgen_reCaptcha_keys = get_option('lxformtempgen_reCaptcha_keys');
        if($lxformtempgen_reCaptcha_keys) {
            $data = $lxformtempgen_reCaptcha_keys;
            $message = 'Success!';
        } else {
            $data = [];
            $message = 'Empty!';
        }

        echo wp_send_json_success([
            'data' => $data,
            'message' => __($message, 'lxformtempgen')
        ], 200);
        wp_die();
    }
}