<?php

class LXFormTempGen_WpAjax_SmtpGetDetails {

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }

    public function init() {
        $this->loader->add_action('wp_ajax_lxftg_smtp_get_details', $this, 'request');
        $this->loader->add_action('wp_ajax_nopriv_lxftg_smtp_get_details', $this, 'request');
    }

    public function request() {
        if ( !$this->loader->verify_nonce( 'lxformtempgen-nonce' ) ) {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Permission Denied!', 'lxformtempgen')
            ]);
            wp_die();
        }

        $lxformtempgen_smtp_setting = get_option('lxformtempgen_smtp_setting');
        if($lxformtempgen_smtp_setting) {
            $data = $lxformtempgen_smtp_setting;
            $message = 'Success!';
        } else {
            $data = [];
            $message = 'Empty!';
        }

        echo wp_send_json_success([
            'data' => $data,
            'message' => __($message, 'lxformtempgen')
        ], 200);
        wp_die();
    }
}