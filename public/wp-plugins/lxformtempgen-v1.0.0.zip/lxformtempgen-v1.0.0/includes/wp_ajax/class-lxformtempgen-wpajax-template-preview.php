<?php

class LXFormTempGen_WpAjax_TemplatePreview {

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }

    public function init() {
        $this->loader->add_action('wp_ajax_lxftg_template_preview', $this, 'request');
        $this->loader->add_action('wp_ajax_nopriv_lxftg_template_preview', $this, 'request');
    }

    public function request() {
        if ( !$this->loader->verify_nonce( 'lxformtempgen-nonce' ) ) {
            echo wp_send_json_error(__('Permission Denied!', 'lxformtempgen'));
            wp_die();
        }

        $form_data = isset( $_POST['form_data'] ) ? wp_unslash( $_POST['form_data'] ) : '';
        $template = (new LXFormTempGen_FormTemplate)->set($form_data)->output();
        
        ob_start();
        echo $template;
        $output = ob_get_contents();
        ob_end_clean();

        echo wp_send_json_success([
            'data' => $output,
            'message' => __('Success', 'lxformtempgen')
        ], 200);
        wp_die();
    }
}