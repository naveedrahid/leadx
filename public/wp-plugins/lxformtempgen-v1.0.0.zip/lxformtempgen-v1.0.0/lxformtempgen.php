<?php

/**
 * @wordpress-plugin
 * Plugin Name:       LeadXForms Template Generator
 * Plugin URI:        -
 * Description:       -
 * Version:           1.0.0
 * Author:            Pixelz360
 * Author URI:        https://pixelz360.com.au/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       lxformtempgen
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) or die( 'Access Denied!' );

define('LXFORMTEMPGEN_VERSION', '1.0.0');
define('LXFORMTEMPGEN_NAME', 'LeadXForms Template Generator');
define('LXFORMTEMPGEN_ID', 'lxformtempgen');

register_activation_hook( __FILE__, function() {  
	flush_rewrite_rules();
});

register_deactivation_hook( __FILE__, function() {  
	flush_rewrite_rules();
});

require_once plugin_dir_path(__FILE__) . '/includes/class-lxformtempgen.php';

function run_lxformtempgen() {
	$plugin = new LXFormTempGen();
	$plugin->run();
}
run_lxformtempgen();