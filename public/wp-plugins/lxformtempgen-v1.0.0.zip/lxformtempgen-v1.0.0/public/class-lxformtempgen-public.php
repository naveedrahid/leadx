<?php

class LXFormTempGen_Public {
	private $loader;

	public function __construct( $loader ) {
		$this->loader = $loader;
	}

	public function init() {
		$this->loader->add_action( 'wp_enqueue_scripts', $this, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $this, 'enqueue_scripts' );
	}

	public function enqueue_styles() {
		wp_enqueue_style( LXFORMTEMPGEN_ID, plugin_dir_url( __FILE__ ) . 'css/'.LXFORMTEMPGEN_ID.'-public.css', array(), LXFORMTEMPGEN_VERSION, 'all' );
	}

	public function enqueue_scripts() {
		wp_enqueue_script( LXFORMTEMPGEN_ID, plugin_dir_url( __FILE__ ) . 'js/'.LXFORMTEMPGEN_ID.'-public.js', array( 'jquery' ), LXFORMTEMPGEN_VERSION, true );
	}
}
