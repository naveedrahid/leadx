<?php

class LXFormTempGen_WpAjax_TemplateSubmit {
    use LXFormTempGen_Trait_Validator;

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }

    public function init() {
        $this->loader->add_action('wp_ajax_lxftg_form_submit', $this, 'request');
        $this->loader->add_action('wp_ajax_nopriv_lxftg_form_submit', $this, 'request');
    }

    public function request() {
        session_start();

        if ( !$this->loader->verify_nonce( 'lxformtempgen-nonce' ) ) {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Permission Denied!', 'lxformtempgen')
            ]);
            wp_die();
        }

        if(!$this->loader->is_internet_on()) {
            $message = 'Please check your internet connection or try again later';
            echo wp_send_json_error([
                'errors' => [],
                'message' => __($message, 'lxformtempgen')
            ]);
            wp_die();
        }

        if (isset($_POST['request-checker'])) {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Spam detected!', 'lxformtempgen')
            ]);
            wp_die();
        }

        $form_key = (isset($_POST['_key'])) ? $_POST['_key'] : '';
        if($form_key === '') {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Invalid Request', 'lxformtempgen')
            ]);
            wp_die();
        }

        $response = wp_remote_get( $this->loader->api_url() . '/template?form_key=' . $form_key, [
            'sslverify' => false
        ]);

        if ( is_wp_error( $response ) ) {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Could not connect to the API', 'lxformtempgen')
            ]);
            wp_die();
        }
        
        $body = wp_remote_retrieve_body( $response );
        $result = json_decode( $body );
        
        if ( empty( $result ) || empty( $result->data ) || !is_array( $result->data ) || !count( $result->data ) ) {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Form Not Found', 'lxformtempgen')
            ]);
            wp_die();
        } elseif ( !isset( $result->data[0]->form_key ) || $result->data[0]->form_key !== $form_key ) {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Form Not Found', 'lxformtempgen')
            ]);
            wp_die();
        }
        
        $form_data = $result->data[0];
        $form_template = (new LXFormTempGen_FormTemplate())->set($form_data->template);
        $messages = !empty($form_data->messages) ? (array) json_decode($form_data->messages) : [];
        $settings = !empty($form_data->settings) ? (array) json_decode($form_data->settings) : [
            "after_redirect" => false,
            "redirect_url" => '',
            "has_limit" => false,
            "submission_limit" => 0,
        ];
        $rules = $form_template->rules();
        $names = $form_template->names();
        $fields = $form_template->fields();

        $mails = $form_data->mail_settings;
        if(!count($mails)) {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Mail Data Not Found', 'lxformtempgen')
            ]);
            wp_die();
        }
        
        if(isset($fields['recaptcha'])) {
            $captcha_response = isset($_POST['g-recaptcha-response']) ? $_POST['g-recaptcha-response'] : '';
            if($captcha_response == '') {
                $message = 'Please verify that you are not a robot';
                echo wp_send_json_error([
                    'errors' => [],
                    'message' => __($message, 'lxformtempgen')
                ]);
                wp_die();
            }

            $validateReCaptcha = $this->validateReCaptcha($captcha_response);
            if($validateReCaptcha === false) {
                $message = 'invalid reCaptcha';
                echo wp_send_json_error([
                    'errors' => [],
                    'message' => __($message, 'lxformtempgen')
                ]);
                wp_die();
            }
        }
        
        $data = [];
        if(count($names)>0) {
            foreach($names as $name) {
                if(isset($_POST[$name])) {
                    $data[$name] = $_POST[$name];
                }

                if(isset($_FILES[$name])) {
                    $data[$name] = $_FILES[$name];
                }
            }
        }

        $this->set_messages($messages);
        $validate = $this->validate($data, $rules, $fields);
        if($validate) {
            $formlead = [];
            if(count($fields)>0) {
                foreach($fields as $field => $field_names) {
                    if(count($field_names)>0) {
                        foreach($field_names as $name) {
                            if(isset($_POST[$name])) {
                                $formlead[$field][$name] = $_POST[$name];
                            }

                            if(isset($_FILES[$name])) {
                                $file = $_FILES[$name];
                                $upload = wp_handle_upload( $file, array( 'test_form' => false ));
                                if( isset( $upload['file'] ) ) {
                                    $filename = basename( $upload['file'] );
                                    $filetype = wp_check_filetype( $filename );
                                    $fileurl = $upload['url'];
                                    $formlead[$field][$name] = [
                                        'name' => $filename,
                                        'type' => $filetype['type'],
                                        'url' => $fileurl
                                    ];
                                } else {
                                    $message = isset($messages['upload_failed']) ? $messages['upload_failed'] : 'An unforeseen issue occurred while attempting to upload the file.';
                                    echo wp_send_json_error([
                                        'errors' => [],
                                        'message' => __($message, 'lxformtempgen')
                                    ]);
                                    wp_die();
                                }
                            }
                        }
                    }
                }
            }

            $send = false;
            if(count($mails)) {
                foreach($mails as $index => $mail) {
                    $mailData = (new LXFormTempGen_MailDataFilter)->set($mail, $formlead);
                    $mailObj = $mailData->data();

                    $recipients = [];
                    if(!empty($mailObj->recipient)) {
                        foreach($mailObj->recipient as $recipient) {
                            if(!empty($recipient->name)) {
                                $recipients[] = sprintf('%s <%s>', $recipient->name, $recipient->email);
                            } else {
                                $recipients[] = sprintf('%s', $recipient->email);
                            }
                        }
                    }

                    $headers = [];
                    if($mailObj->use_html == "1") {
                        $headers[] = 'Content-Type: text/html; charset=UTF-8';
                    }
        
                    if(!empty($mailObj->sender)) {
                        if(!empty($mailObj->sender[0]->name)) {
                            $headers[] = sprintf('From: %s <%s>', $mailObj->sender[0]->name, $mailObj->sender[0]->email);
                        } else {
                            $headers[] = sprintf('From: %s', $mailObj->sender[0]->email);
                        }
                    }

                    if(!empty($mailObj->cc)) {
                        foreach($mailObj->cc as $cc) {
                            $headers[] = sprintf('Cc: %s', $cc->email);
                        }
                    }
        
                    if(!empty($mailObj->bcc)) {
                        foreach($mailObj->bcc as $bcc) {
                            $headers[] = sprintf('Bcc: %s', $bcc->email);
                        }
                    }
        
                    if(!empty($mailObj->replay_to)) {
                        $headers[] = sprintf('Reply-To: %s', $mailObj->replay_to);
                    }
        
                    $subject = $mailObj->topic;
                    $message = $mailObj->body;
        
                    $attachments = [];
                    if(!empty($mailObj->attachment)) {
                        foreach($mailObj->attachment as $attachment) {
                            $attachments[] = $attachment->file;
                        }
                    }

                    $send = wp_mail( $recipients, $subject, $message, $headers, $attachments );
                }
            }

            if($send) {
                if(count($formlead)>0) {
                    if(isset($formlead['file'])) {
                        foreach($formlead['file'] as $key => $file) {
                            $file_path = str_replace( site_url('/'), ABSPATH, $file['url'] );
                            if (file_exists($file_path)) {
                                wp_delete_file($file_path);
                            }
                        }
                    }
                }

                $redirect = 'none';
                if(
                    (isset($settings['after_redirect']) && $settings['after_redirect'] == true) &&
                    (isset($settings['redirect_url']) && !empty($settings['redirect_url']))
                ) {
                    $redirect = $settings['redirect_url'];
                }
                
                $message = isset($messages['mail_sent']) ? $messages['mail_sent'] : 'Message has been sent successfully';
                echo wp_send_json_success([
                    'redirect' => $redirect,
                    'message' => __($message, 'lxformtempgen')
                ], 200);
                wp_die();
            } else {
                $message = isset($messages['sending_failed']) ? $messages['sending_failed'] : 'An attempt to send your message encountered an error. Please retry at a later time.';
                echo wp_send_json_error([
                    'errors' => [],
                    'message' => __($message, 'lxformtempgen')
                ]);
                wp_die();
            }
        } else {
            $message = isset($messages['validation_error']) ? $messages['validation_error'] : 'There was an error in one or more fields. Please double-check and try again.';
            echo wp_send_json_error([
               'errors' => $this->getErrors(),
               'message' => __($message, 'lxformtempgen') 
            ]);
            wp_die();
        }
    }

    public function get_visitor_info() {
        $visitor_details = new LXFormTempGen_VisitorDetails();
        $ip = $visitor_details->get_ip_address();    
        $platform = $visitor_details->get_os();
        $browser = $visitor_details->get_browser();
        $ref_url = $visitor_details->get_ref_url();
        $location = $visitor_details->get_country();

        return [
            'ip' => $ip,
            'platform' => $platform,
            'browser' => $browser,
            'ref_url' => $ref_url,
            'country' => $location['country'],
            'state' => $location['state'],
            'city' => $location['city'],
            'country_code' => $location['country_code'],
            'continent' => $location['continent']
        ];
    }

    public function validateReCaptcha($captcha_response) {
        $keys = get_option('lxformtempgen_reCaptcha_keys');
        $secret_key = ($keys) ? $keys['secret_key'] : '';
        $get_visitor = $this->get_visitor_info();
        $url = 'https://www.google.com/recaptcha/api/siteverify';

        $data = array(
            'secret' => $secret_key,
            'response' => $captcha_response,
            'remoteip' => $get_visitor['ip']
        );

        $options = array(
            'http' => array(
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data)
            )
        );

        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $response = json_decode($result);

        return ($response->success == false) ? false : true;
    }
}