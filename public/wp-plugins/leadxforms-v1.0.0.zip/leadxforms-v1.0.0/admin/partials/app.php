<main class="lxf-wrap">
    <div id="app"></div>
</main>