<main class="lxf-wrap">
    <div id="lxfapp"></div>
</main>