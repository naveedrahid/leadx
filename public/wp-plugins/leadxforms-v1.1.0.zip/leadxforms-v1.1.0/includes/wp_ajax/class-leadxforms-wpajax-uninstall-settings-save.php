<?php

class LeadXForms_WpAjax_UninstallSettingsSave {

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }

    public function init() {
        // Register AJAX actions for logged-in and non-logged-in users
        $this->loader->add_action('wp_ajax_lxf_save_uninstall_settings', $this, 'request');
        $this->loader->add_action('wp_ajax_nopriv_lxf_save_uninstall_settings', $this, 'request');
    }

    public function request() {
        if (!$this->loader->verify_nonce('lxform-nonce')) {
            wp_send_json_error([
                'errors' => [],
                'message' => __('Permission Denied!', 'lxform')
            ]);
        }

        $remove_data_on_uninstall = isset($_POST['remove_data_on_uninstall']) ? $_POST['remove_data_on_uninstall'] : "false";
        $remove_data_on_uninstall = $remove_data_on_uninstall == "true" ? 1 : 0;

        update_option('leadxforms_remove_data_on_uninstall', $remove_data_on_uninstall);

        wp_send_json_success([
            'data' => $remove_data_on_uninstall,
            'message' => __('Settings have been saved successfully', 'lxform')
        ]);
    }
}