<?php

class LeadXForms_WpAjax_FormRestrictionsSettingsGet {

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }

    public function init() {
        $this->loader->add_action('wp_ajax_lxf_get_form_restrictions_settings', $this, 'request');
        $this->loader->add_action('wp_ajax_nopriv_lxf_get_form_restrictions_settings', $this, 'request');
    }

    public function request() {
        if ( !$this->loader->verify_nonce('lxform-nonce') ) {
            wp_send_json_error([
                'errors' => [],
                'message' => __('Permission Denied!', 'lxform')
            ]);
        }

        $form_restrictions = [
            'disallowed_words' => [],
            'disallowed_words_message' => 'Sorry, the entered content contains disallowed words. Please review your input and remove any inappropriate language or terms.',
            'block_ips' => [],
            'block_ips_message' => 'Access Denied!'
        ];
        
        $leadxforms_form_restrictions = get_option('leadxforms_form_restrictions');
        $message = $leadxforms_form_restrictions ? 'Success!' : 'Empty!';

        wp_send_json_success([
            'data' => $leadxforms_form_restrictions ? $leadxforms_form_restrictions : $form_restrictions,
            'message' => __($message, 'lxform')
        ]);
    }
}