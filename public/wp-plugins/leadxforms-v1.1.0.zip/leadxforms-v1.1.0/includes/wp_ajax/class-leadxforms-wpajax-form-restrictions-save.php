<?php

class LeadXForms_WpAjax_FormRestrictionsSettingsSave {

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }

    public function init() {
        // Register AJAX actions for logged-in and non-logged-in users
        $this->loader->add_action('wp_ajax_lxf_save_form_restrictions_settings', $this, 'request');
        $this->loader->add_action('wp_ajax_nopriv_lxf_save_form_restrictions_settings', $this, 'request');
    }

    public function request() {
        if (!$this->loader->verify_nonce('lxform-nonce')) {
            wp_send_json_error([
                'errors' => [],
                'message' => __('Permission Denied!', 'lxform')
            ]);
        }

        $form_restrictions = isset($_POST['form_restrictions']) ? json_decode(wp_unslash($_POST['form_restrictions'])) : '';

        $errors = [];
        if(count($form_restrictions->disallowed_words)) {
            if (empty($form_restrictions->disallowed_words_message)) {
                $errors['disallowed_words_message'] = __('The field is required.', 'lxforms');
            }
        }

        if(count($form_restrictions->block_ips)) {
            if (empty($form_restrictions->block_ips_message)) {
                $errors['block_ips_message'] = __('The field is required.', 'lxforms');
            }
        }

        if (!empty($errors)) {
            wp_send_json_error([
                'message' => __('Validation errors occurred.', 'lxforms'),
                'errors' => $errors
            ], 422);
        } else {
            update_option('leadxforms_form_restrictions', $form_restrictions);
    
            wp_send_json_success([
                'data' => $form_restrictions,
                'message' => __('Settings have been saved successfully', 'lxform')
            ]);
        }

    }
}