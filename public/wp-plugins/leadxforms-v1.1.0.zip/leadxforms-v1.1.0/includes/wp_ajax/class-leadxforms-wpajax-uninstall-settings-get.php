<?php

class LeadXForms_WpAjax_UninstallSettingsGet {

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }

    public function init() {
        $this->loader->add_action('wp_ajax_lxf_get_uninstall_settings', $this, 'request');
        $this->loader->add_action('wp_ajax_nopriv_lxf_get_uninstall_settings', $this, 'request');
    }

    public function request() {
        if ( !$this->loader->verify_nonce('lxform-nonce') ) {
            wp_send_json_error([
                'errors' => [],
                'message' => __('Permission Denied!', 'lxform')
            ]);
        }
        
        $leadxforms_remove_data_on_uninstall = get_option('leadxforms_remove_data_on_uninstall');
        $data = (int) $leadxforms_remove_data_on_uninstall;
        $message = $leadxforms_remove_data_on_uninstall ? 'Success!' : 'Empty!';

        wp_send_json_success([
            'data' => $data,
            'message' => __($message, 'lxform')
        ]);
    }
}