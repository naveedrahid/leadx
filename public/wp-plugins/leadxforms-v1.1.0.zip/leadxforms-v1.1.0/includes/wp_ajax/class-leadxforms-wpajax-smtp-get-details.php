<?php

class LeadXForms_WpAjax_SmtpGetDetails {

    private $loader;

    public function __construct($loader) {
        $this->loader = $loader;
    }

    public function init() {
        $this->loader->add_action('wp_ajax_lxf_smtp_get_details', $this, 'request');
        $this->loader->add_action('wp_ajax_nopriv_lxf_smtp_get_details', $this, 'request');
    }

    public function request() {
        if ( !$this->loader->verify_nonce( 'lxform-nonce' ) ) {
            echo wp_send_json_error([
                'errors' => [],
                'message' => __('Permission Denied!', 'lxform')
            ]);
            wp_die();
        }

        // if(!$this->loader->is_internet_on()) {
        //     $message = 'Please check your internet connection or try again later';
        //     echo wp_send_json_error([
        //         'errors' => [],
        //         'message' => __($message, 'lxform')
        //     ]);
        //     wp_die();
        // }

        $leadxforms_smtp_setting = get_option('leadxforms_smtp_setting');
        if($leadxforms_smtp_setting) {
            $data = $leadxforms_smtp_setting;
            $message = 'Success!';
        } else {
            $data = [];
            $message = 'Empty!';
        }

        echo wp_send_json_success([
            'data' => $data,
            'message' => __($message, 'lxform')
        ], 200);
        wp_die();
    }
}