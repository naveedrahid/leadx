<?php

class LeadXForms_Shortcode_FormTemplatePreview {

    private $loader;

    public function __construct($loader) {
        global $wpdb;
        $this->loader = $loader;
    }
	
    public function init() {
        add_shortcode(lxf_id() . 'tempprev', [$this, 'shortcode']);
    }

    public function shortcode($atts) {
        global $wp;
        $atts = shortcode_atts(['key' => null], $atts);

        if(!empty($atts)) {
            $response = wp_remote_get( $this->loader->api_url() . '/template?form_key=' . $atts['key'], [
                'sslverify' => false
            ]);

            if ( is_wp_error( $response ) ) {
                return '<div class="lxf_template-form-error">Error: Could not connect to the API</div>';
            }
            
            $body = wp_remote_retrieve_body( $response );
            $result = json_decode( $body );
            
            if ( empty( $result ) || empty( $result->data ) || !is_array( $result->data ) || !count( $result->data ) ) {
                return '<div class="lxf_template-form-error">Error: Form Not Found</div>';
            } elseif ( !isset( $result->data[0]->form_key ) || $result->data[0]->form_key !== $atts['key'] ) {
                return '<div class="lxf_template-form-error">Error: Form Not Found</div>';
            }

            $form_data = $result->data[0];
            $template = (new LeadXForms_FormTemplate)->set($form_data->template);
            $rules = $template->rules();
            $names = $template->names();
            $fields = $template->fields();
            $form_template = $template->output();

            wp_enqueue_style( lxf_id() . '_template', plugin_dir_url( __FILE__ ) . '../../public/css/leadxforms_template-public.css', [], null, 'all' );
            if(isset($fields['recaptcha'])) {
                wp_enqueue_script( lxf_id().'-recaptcha', 'https://www.google.com/recaptcha/api.js', [], null, true );    
                wp_script_add_data(lxf_id().'-recaptcha', 'async', true);
                wp_script_add_data(lxf_id().'-recaptcha', 'defer', true);
            }
            wp_enqueue_script( lxf_id() . '_template', plugin_dir_url( __FILE__ ) . '../../public/js/leadxforms_template-public.js', [], null, true );

            wp_localize_script( lxf_id() . '_template', 'lxformtempData', array(
                'ajax_url' => admin_url( 'admin-ajax.php' )
            ));

            if($form_data->custom_css) {
                wp_add_inline_style( lxf_id() . '_template', $form_data->custom_css );
            }

            ob_start(); ?>
            <div class="lxf_template-form-wrap">
                <form action="<?php echo home_url( $wp->request ); ?>" method="post" class="lxf_template-form" aria-label="<?php echo $form_data->form_name; ?>" novalidate>
                    <?php wp_nonce_field( 'lxform-nonce', 'nonce' ); ?>
                    <input type="hidden" name="lxfstarttime" value="<?= time(); ?>">
                    <label for="request-checker" aria-hidden="true" class="request-checker"><input type="radio" name="request-checker" id="request-checker" value="1"></label>
                    <div class="lxf_template-form-innerwrap">
                        <input type="hidden" name="_key" value="<?php echo $form_data->form_key; ?>">
                        <?php echo $form_template; ?>
                    </div>
                </form>
            </div>
            <?php $output = ob_get_contents();
            ob_end_clean();

            return $output;
        }
    }
}