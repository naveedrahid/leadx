<?php

defined( 'WP_UNINSTALL_PLUGIN' ) or die();

$remove_data = (int) get_option('leadxforms_remove_data_on_uninstall');
if($remove_data) {
    $migration = new LeadXForms_Database_Migration();
    $migration->rollback();
}