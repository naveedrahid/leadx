<?php

/**
 * @wordpress-plugin
 * Plugin Name:       LeadXForms
 * Plugin URI:        https://leadxforms.com/
 * Description:       The Unlimited solution for creating custom forms and flows to connect users and enhance engagement and broaden your online presence.
 * Version:           1.1.0
 * Author:            Pixelz360
 * Author URI:        https://pixelz360.com.au/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       lxform
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) or die( 'Access Denied!' );

define('LXFORM_PLUGIN_VERSION', '1.1.0');
define('LXFORM_PLUGIN_NAME', 'LeadXForms');
define('LXFORM_PLUGIN_ID', 'leadxforms');

function activate_leadxforms() {
	require_once plugin_dir_path(__FILE__) . '/includes/class-leadxforms-activator.php';
	LeadXForms_Activator::activate();
}

function deactivate_leadxforms() {
	require_once plugin_dir_path(__FILE__) . '/includes/class-leadxforms-deactivator.php';
	LeadXForms_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_leadxforms' );
register_deactivation_hook( __FILE__, 'deactivate_leadxforms' );

require_once plugin_dir_path(__FILE__) . '/includes/helpers.php';
require_once plugin_dir_path(__FILE__) . '/includes/class-leadxforms.php';

function run_leadxforms() {
	$plugin = new LeadXForms();
	$plugin->run();
}
run_leadxforms();