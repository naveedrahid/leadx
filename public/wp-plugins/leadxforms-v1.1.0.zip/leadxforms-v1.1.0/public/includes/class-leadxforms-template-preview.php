<?php

class LeadXForms_TemplatePreview {

    public function __construct() {
        add_action('init', [$this, 'add_rewrite_rules']);
        add_filter('query_vars', [$this, 'add_query_vars']);
        add_action('template_redirect', [$this, 'template_redirect']);
    }

    public function add_rewrite_rules() {
        add_rewrite_rule(
            '^leadxformtemp-preview/?$',
            'index.php?leadxformtemp_preview=1',
            'top'
        );
    }

    public function add_query_vars($vars) {
        $vars[] = 'leadxformtemp_preview';
        $vars[] = 'key';
        return $vars;
    }

    public function template_redirect() {
        if (get_query_var('leadxformtemp_preview') == 1) {
            $this->render_form_preview();
            exit;
        }
    }

    private function render_form_preview() {
        get_header();

        $key = get_query_var('key');
        if ($key) {
            echo '<div class="lxf_template-preview-content">';
                echo '<div class="lxf_template-preview-head">';
                    echo '<h1>Form Preview</h1>';
                echo '</div>';
                echo '<div class="lxf_template-preview-form">';
                    echo do_shortcode('['. lxf_id() .'tempprev key="'. esc_html($key) .'"]');
                echo '</div>';
            echo '</div>';
        } else {
            echo '<div class="lxf_template-form-error">No Template Key Provided.</div>';
        }

        get_footer();
    }
}